<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<link rel="stylesheet" href="/js/jquery-ui/jquery-ui.min.css" type="text/css"/>


<style>
#update
{
	position: absolute;
	top: 0px;
	left: 0px;
	z-index: 1000;
}
.lpgatewaywidget
{
	position: absolute;
	font-family: Poppins;
}

::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 8px;
}

::-webkit-scrollbar-track {
    background-color: #c0c0c0;
    border-radius: 4px;
}
::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background-color: grey;
}

</style>
<script src="/js/jquery.js"></script>
<script src="/js/jquery-ui/jquery-ui.js"></script>
<script>
$(
	function()
	{
	 

	// create the links on the widgets
	makewidgetlinks();



	
		      // ajaxSend event to handle the tiemout of the sessionkeepalivepoller
      			$(document).ajaxSend(
         			function(event, request,settings)
         			{
            				// if it's not a keepalive poll
            				if(!settings.url.endsWith('keepalive.php'))
               					// reset keepalivecounter
               					keepalivecounter = 600*2;

         			}
      			);


      			// set an interval to keep the session alive
      			setInterval(
         			function()
         			{
            				sessionkeepalivepoller();
         			},
         			30000
      			);

	
	}
);



// a stack variable to count down from for keepalive (in minutes*2 as we poll every 30secs)
var keepalivecounter = 600*2;


// a function for out session keepalive
function sessionkeepalivepoller()
{
   // only continue is the keealive counter is positive
   if(keepalivecounter <= 0)
      return;

   $.ajax(
      {
         url: '/keepalive.php',
         success: function(data)
         {
            // decrease keepalivecounter
            keepalivecounter--;
         }
      }
   );
}





// a function to create clickable links on widgets
function makewidgetlinks()
{
	// possible links for all widgets
	$('.lpgatewaywidget').each(

		function()
		{
			makewidgetclick($(this));
		}
	);


}

// construct the click event for a particular widget
function makewidgetclick(widget)
{
	// remove the click event listener first
	widget.off('click');


	// if there is a link property
	if(widget.attr('lplink'))
	{

		// set the cursor to show a pointer
		widget.css('cursor','pointer');


		// link target
		if(widget.attr('lplinktarget') == 'same')
		{
			// link type
			if(widget.attr('lplinktype') == 'local')
			{
				widget.click(
					function(event)
					{
						event.stopPropagation();

						// catch single slash for 'home'
						var linkpath = widget.attr('lplink');

						if(linkpath == '/')
							linkpath = '';


							window.location = '/' + linkpath;
					}
				);
			}
			else
			{
				widget.click(
					function(event)
					{
						event.stopPropagation();

							window.location = widget.attr('lplink');
					}
				);
			}
		}
		else
		{
			// link type
			if(widget.attr('lplinktype') == 'local')
			{
				widget.click(
					function(event)
					{
						event.stopPropagation();
						window.open('/' + widget.attr('lplink'),'');
					}
				);
			}
			else
			{
				widget.click(
					function(event)
					{
						event.stopPropagation();
						window.open(widget.attr('lplink'));
					}
				);
			}
		}

			
	}
	else
	{
		// set the cursor
		widget.css('cursor','default');


		// add a non propagating click event doing nothing
		widget.click(
			function(event)
			{
				event.stopPropagation();
			}
		);
	}
}




	


</script>
</head>
<body>
</body> 
